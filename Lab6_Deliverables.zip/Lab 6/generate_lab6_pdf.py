import os
from PIL import Image, ImageDraw, ImageFont

lab6_dir = "/Users/kcnandan/.gemini/antigravity/scratch/car_rental_rate/Lab 6"
pdf_path = os.path.join(lab6_dir, "Lab6_Coverage_Analysis_Report.pdf")

img_code = Image.open(os.path.join(lab6_dir, "screenshot_code_coverage.png"))
img_branch = Image.open(os.path.join(lab6_dir, "screenshot_branch_coverage.png"))
img_full = Image.open(os.path.join(lab6_dir, "screenshot_full_coverage.png"))

page_w, page_h = 1240, 1754
pages = []

def create_page(title, subtitle, img):
    page = Image.new("RGB", (page_w, page_h), (255, 255, 255))
    draw = ImageDraw.Draw(page)

    # Header banner
    draw.rectangle([0, 0, page_w, 140], fill=(15, 23, 42))
    
    try:
        h1_font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 30)
        h2_font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 18)
        foot_font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 15)
    except Exception:
        h1_font = ImageFont.load_default()
        h2_font = ImageFont.load_default()
        foot_font = ImageFont.load_default()

    draw.text((60, 35), title, fill=(255, 255, 255), font=h1_font)
    draw.text((60, 85), subtitle, fill=(148, 163, 184), font=h2_font)

    max_img_w = page_w - 120
    max_img_h = page_h - 260
    scale = min(max_img_w / img.width, max_img_h / img.height, 1.0)
    target_w = int(img.width * scale)
    target_h = int(img.height * scale)
    scaled_img = img.resize((target_w, target_h), Image.Resampling.LANCZOS)

    pos_x = (page_w - target_w) // 2
    pos_y = 180 + (max_img_h - target_h) // 4
    page.paste(scaled_img, (pos_x, pos_y))

    draw.line([60, page_h - 60, page_w - 60, page_h - 60], fill=(226, 232, 240), width=1)
    draw.text((60, page_h - 45), "Lab 6: Code and Branch Coverage Analysis | Deliverables Report", fill=(100, 116, 139), font=foot_font)
    return page

pages.append(create_page(
    "Lab 6: Statement / Line Coverage Analysis (100%)",
    "Command: coverage run -m pytest CodeCoverageTest_car_rental_rate.py && coverage report -m",
    img_code
))

pages.append(create_page(
    "Lab 6: Decision / Branch Coverage Analysis (100%)",
    "Command: coverage run --branch -m pytest BranchCoverageTest_car_rental_rate.py && coverage report -m",
    img_branch
))

pages.append(create_page(
    "Lab 6: Comprehensive Test Suite Coverage (100% Line & Branch)",
    "Command: coverage run --branch -m pytest test_car_rental.py && coverage report -m",
    img_full
))

pages[0].save(pdf_path, save_all=True, append_images=pages[1:], resolution=150.0)
print(f"Generated Lab 6 PDF report: {pdf_path}")
