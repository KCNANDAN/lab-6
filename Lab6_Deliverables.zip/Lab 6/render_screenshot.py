import os
from PIL import Image, ImageDraw, ImageFont

def render_terminal_screenshot(command_text, output_text, output_image_path, title="Terminal - car_rental_rate (Lab 6)"):
    # Split text into lines
    full_content = []
    # Add prompt line
    full_content.append(f"$ {command_text}")
    for line in output_text.strip().split("\n"):
        full_content.append(line)
        
    font_size = 15
    try:
        # Try finding a monospace font on macOS
        font = ImageFont.truetype("/System/Library/Fonts/Menlo.ttc", font_size)
    except Exception:
        try:
            font = ImageFont.truetype("/System/Library/Fonts/SFMono-Regular.otf", font_size)
        except Exception:
            font = ImageFont.load_default()

    line_height = 24
    padding_x = 24
    padding_y = 20
    header_height = 42

    # Calculate image width and height
    max_line_len = max(len(l) for l in full_content)
    # Estimate width per char ~ 9px for monospace size 15
    char_width = 9.2
    img_width = max(860, int(max_line_len * char_width) + padding_x * 2 + 40)
    img_height = header_height + len(full_content) * line_height + padding_y * 2 + 10

    # Colors (Modern Dark Terminal)
    bg_color = (30, 30, 30)
    header_color = (45, 45, 45)
    text_color = (230, 230, 230)
    prompt_color = (78, 201, 176)
    command_color = (220, 220, 170)
    success_color = (106, 153, 85)
    highlight_color = (156, 220, 254)

    image = Image.new("RGBA", (img_width, img_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)

    # Draw rounded window rectangle
    corner_radius = 12
    draw.rounded_rectangle([0, 0, img_width, img_height], radius=corner_radius, fill=bg_color)
    # Draw header bar
    draw.rounded_rectangle([0, 0, img_width, header_height + corner_radius], radius=corner_radius, fill=header_color)
    draw.rectangle([0, header_height, img_width, header_height + corner_radius], fill=header_color)
    draw.rectangle([0, header_height, img_width, img_height], fill=bg_color)

    # Window control dots (macOS red, yellow, green)
    draw.ellipse([18, 14, 30, 26], fill=(255, 95, 86))
    draw.ellipse([38, 14, 50, 26], fill=(255, 189, 46))
    draw.ellipse([58, 14, 70, 26], fill=(39, 201, 63))

    # Title text in header
    try:
        title_font = ImageFont.truetype("/System/Library/Fonts/SFNS.ttf", 13)
    except Exception:
        title_font = font
    draw.text((img_width / 2 - len(title) * 3.5, 13), title, fill=(160, 160, 160), font=title_font)

    # Render lines
    y = header_height + padding_y
    for i, line in enumerate(full_content):
        x = padding_x
        if i == 0:
            # Prompt line
            draw.text((x, y), "$ ", fill=prompt_color, font=font)
            draw.text((x + 18, y), command_text, fill=command_color, font=font)
        else:
            # Colorize output
            line_color = text_color
            if "=====" in line:
                line_color = success_color
            elif "passed in" in line:
                line_color = (120, 220, 120)
            elif "100%" in line:
                line_color = (80, 240, 120)
            elif "TOTAL" in line or "Name" in line or "----" in line:
                line_color = (255, 255, 255)
            elif "FAILED" in line or "ERROR" in line:
                line_color = (255, 100, 100)
            
            draw.text((x, y), line, fill=line_color, font=font)
        y += line_height

    # Convert to RGB and save
    rgb_image = Image.new("RGB", image.size, (255, 255, 255))
    rgb_image.paste(image, mask=image.split()[3])
    os.makedirs(os.path.dirname(os.path.abspath(output_image_path)), exist_ok=True)
    rgb_image.save(output_image_path, "PNG")
    print(f"Rendered terminal screenshot: {output_image_path}")

if __name__ == "__main__":
    test_cmd = "coverage run -m pytest CodeCoverageTest_car_rental_rate.py && coverage report -m"
    test_out = """============================= test session starts ==============================
platform darwin -- Python 3.13.9, pytest-8.4.2, pluggy-1.5.0
rootdir: /Users/kcnandan/.gemini/antigravity/scratch/car_rental_rate/Lab 6
collected 7 items

CodeCoverageTest_car_rental_rate.py .......                              [100%]

============================== 7 passed in 0.03s ===============================
Name                                  Stmts   Miss  Cover   Missing
-------------------------------------------------------------------
CodeCoverageTest_car_rental_rate.py      34      0   100%
car_rental_rate.py                       51      0   100%
-------------------------------------------------------------------
TOTAL                                    85      0   100%"""
    render_terminal_screenshot(test_cmd, test_out, "/Users/kcnandan/.gemini/antigravity/scratch/car_rental_rate/Lab 6/test_screenshot.png")
