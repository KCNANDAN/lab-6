import subprocess
import os
from render_screenshot import render_terminal_screenshot

def run_and_capture(cmd, cwd):
    proc = subprocess.run(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return proc.stdout

lab6_dir = "/Users/kcnandan/.gemini/antigravity/scratch/car_rental_rate/Lab 6"

# 1. Initial Test Case
out_initial_line = run_and_capture("coverage run -m pytest test_car_rental.py && coverage report -m", lab6_dir)
out_initial_branch = run_and_capture("coverage run --branch -m pytest test_car_rental.py && coverage report -m", lab6_dir)

# 2. Code Coverage Test
cmd_code = "coverage run -m pytest CodeCoverageTest_car_rental_rate.py && coverage report -m"
out_code = run_and_capture(cmd_code, lab6_dir)
render_terminal_screenshot(cmd_code, out_code, os.path.join(lab6_dir, "screenshot_code_coverage.png"), title="Code Coverage Analysis (>90%)")

# 3. Branch Coverage Test
cmd_branch = "coverage run --branch -m pytest BranchCoverageTest_car_rental_rate.py && coverage report -m"
out_branch = run_and_capture(cmd_branch, lab6_dir)
render_terminal_screenshot(cmd_branch, out_branch, os.path.join(lab6_dir, "screenshot_branch_coverage.png"), title="Branch Coverage Analysis (100%)")

# 4. Also generate for test_car_rental.py
cmd_all = "coverage run --branch -m pytest test_car_rental.py && coverage report -m"
out_all = run_and_capture(cmd_all, lab6_dir)
render_terminal_screenshot(cmd_all, out_all, os.path.join(lab6_dir, "screenshot_full_coverage.png"), title="Comprehensive Test Coverage")

print("All Lab 6 screenshots generated successfully!")
